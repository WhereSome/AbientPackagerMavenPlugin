一、场景：支持 Ubuntu 20.04 / 22.04 / 24.04 及 Debian 11 以上，x86_64 与 aarch64 架构
	推荐系统：Ubuntu 20.04 及以上
	内核查看：uname -r
	架构查看：uname -m

二、功能：

1）部署 yq

yq 是一个轻量级的便携式命令行 YAML 处理器，JAR 部署脚本修改 application.yml 时依赖它。

三、注意事项：

注意1：操作用户的身份：root或者sudo用户
注意2：Ubuntu 版将二进制安装到 /usr/bin/yq，与 CentOS 版路径一致

四、使用方法：

1）cd yq_install
2）sh main.sh

语法参考：https://lyyao09.github.io/2019/08/02/tools/The-usage-of-yq-read-write/
