#!/bin/bash
#

if [ ! -x /usr/bin/sudo ]; then
    echo "Error: command /usr/bin/sudo isn't existed"
    exit 1
fi

if sudo -l &> /dev/null; then
    :
else
    echo "Error: you must switch root or sudo user"
    exit 1
fi

# Ubuntu 内核名通常是 5.15.0-91-generic，不能从 uname -r 末尾取架构
if ! uname -m | grep -E -sq "^(aarch64|x86_64)$"; then
    echo "Error: the os architecture isn't aarch64 or x86_64"
    exit 1
fi

if [ -f /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    if [ "$ID" != "ubuntu" ] && ! echo " ${ID_LIKE} " | grep -qw debian; then
        echo "Warn: this script is intended for Ubuntu/Debian, current OS: ${ID:-unknown}"
    fi
fi

if ! sudo chmod 755 ./bin/exec.sh; then
    echo "Error: you must switch root or sudo user"
    exit 1
fi

sudo chmod 755 ./{bin,conf,software} &>/dev/null

if [ ! -f ./bin/exec.sh ]; then
    echo "Error: bin/exec.sh isn't existed"
    exit 1
fi

./bin/exec.sh
