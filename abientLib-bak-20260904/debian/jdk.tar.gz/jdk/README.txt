一、场景: 支持 Ubuntu 20.04 / 22.04 / 24.04 及 Debian 11 以上，x86_64 与 aarch64 架构
内核查看: uname -r
架构查看: uname -m

与 CentOS 版的关键差异:
1) 架构取自 uname -m，不再解析 uname -r（Ubuntu 内核名以 -generic 结尾）
2) 包管理使用 apt-get，不再使用 yum
3) Java 命令注册使用 update-alternatives，不再使用 alternatives

二、功能：

1)安装JDK8
2)安装JDK11
3)安装JDK17

三、注意事项：

1)操作用户的身份：root或者sudo用户
2)JDK包必须上传(此方法适用于jdk多版本共存)
   2.1) 内网下载地址(优先使用内网地址)：http://192.168.90.117/pc/开发环境/linux/
   2.2) 公网下载地址：https://www.azul.com/downloads/#zulu
3)安装目录仍为 /usr/java/，默认 JAVA_HOME=/usr/java/default，与 JAR 部署脚本保持一致

四、使用方法：
下载并解压 jdk.tar.gz 包
1) cd jdk
    1.1) 查看架构命令: uname -m
			若为 x86_64 架构则下载对应系统的包 zulu*-linux_x64.tar.gz;
			若为 aarch64 架构则下载对应系统的包 zulu*-linux_aarch64.tar.gz
将 zulu*-ca-jdk*-linux_*.tar.gz 包上传到解压后 jdk/software 目录即可，tar.gz 不用解压。
2) bash main.sh
3) 交互式选项:在已上传到软件目录的JDK版本包中请输入你要安装的JDK版本的标题编号:
    3.1)如果不是存在序列内的数字 会报错并退出
4) 交互式选项:是否需要更新当前的默认JDK
4.1)此方法适用于jdk多版本共存:
	4.1.1) 若选择更新就会更新默认jdk指向当前所更新的版本并修改环境变量中的jdk
	4.1.2) 若选择不更新就会仅解压当前jdk到/usr/java目录不变更环境变量中的jdk程序若要使用此jdk需要手动修改目标路径
