#!/bin/bash
#

if [ ! -x /usr/bin/sudo ]; then
    echo "Error: command /usr/bin/sudo isn't existed"
    exit 1
fi

if sudo -l &> /dev/null; then
    :
else
    echo "Error: you must switch root or sudo user"
    exit 1
fi

# if ! uname -r|grep -sq "\.x86_64$"; then
#     echo "Error: the os architecture isn't x86" 
#     exit 1
# fi

if [ ! -f ./bin/exec.sh ]; then
    echo "Error: bin/exec.sh isn't existed"
    exit 1
elif ! sudo chmod 755 ./bin/exec.sh; then
    echo "Error: you must switch root or sudo user"
    exit 1
fi

sudo chmod 755 ./{bin,conf,software} &>/dev/null

./bin/exec.sh
