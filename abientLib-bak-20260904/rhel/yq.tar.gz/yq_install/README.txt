﻿一、场景：支持主流linux的x86_64架构和aarch64架构
	推荐系统：anolis8以上、uos-v20-1020x以上、kylin10、centos8以上
	内核查看：uname -r

二、功能：

1）部署yq

yq是一个轻量级的便携式命令行YAML处理器，用于yaml文件处理

三、注意事项：

注意1：操作用户的身份：root或者sudo用户


四、使用方法：

1）cd yq-install
2）sh main.sh

语法参考：https://lyyao09.github.io/2019/08/02/tools/The-usage-of-yq-read-write/
