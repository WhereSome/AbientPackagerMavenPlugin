﻿一、场景: 支持主流linux版本分支，服务器3.10.0-123内核及以上系统、不支持系统小于3.10.0-123版本的内核  
推荐系统: anolis8以上、uos-v20-1020x以上、kylin10、openEuler、fusion22
内核查看: uname -r

1)支持x86_64架构和aarch64架构

二、功能：

1)安装JDk8
2)安装JDK11
2)安装JDK17

三、注意事项：

1)操作用户的身份：root或者deploy用户
2)JDK包必须上传(此方法适用于jdk多版本共存)
   2.1) 内网下载地址(优先使用内网地址)：http://192.168.90.117/pc/开发环境/linux/
   2.2) 公网下载地址：https://www.azul.com/downloads/#zulu

四、使用方法：
下载并解压jdk.tar.gz包 
1)cd jdk-install
    1.1)查看架构命令: uname -r | awk -F '[.]' '{print $NF}' 
			若为x86_64架构则下载对应系统的包zulul*-linux_x86_64.tar.gz;
			若为aarch64架构则下载对应系统的包zulul*-linux_aarch64.tar.gz
将zulul*-ca-jdk*-linux_*.tar.gz包上传到jdk-install.tar.gz解压后jdk-install/software的目录即可，zulul*-ca-jdk*-linux_*.tar.gz不用解压。
2)bash main.sh
3)交互式选项:在已上传到软件目录的JDK版本包中请输入你要安装的JDK版本的标题编号:
    3.1)如果不是存在序列内的数字 会报错并退出
4)交互式选项:是否需要更新当前的默认JDK
4.1)此方法适用于jdk多版本共存:
	4.1.1) 若选择更新就会更新默认jdk指向当前所更新的版本并修改环境变量中的jdk
	4.1.2) 若选择不更新就会仅解压当前jdk到/usr/java目录不变更环境变量中的jdk程序若要使用此jdk需要手动修改目标路径
